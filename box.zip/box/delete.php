<?php
include "connection.php";
$id = $_GET["id"];
$sql = "DELETE FROM `allitems` WHERE itemid = $id";
$result = mysqli_query($conn, $sql);

if ($result) {
  header("Location: list.php?msg=Data deleted successfully");
} else {
  echo "Failed: " . mysqli_error($conn);
}
