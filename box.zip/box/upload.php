<?php 
    if(isset($_POST['submit'])) {
        include("connection.php");
        $items = mysqli_real_escape_string($conn, $_POST['items']);

        $sql = "INSERT INTO allitems (items) VALUES ('$items')";

        $query = mysqli_query($conn, $sql);

        if($query) {
            echo "<script>alert('Data inserted');</script>";
        } else {
            echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add items into the box</title>
    <link rel="stylesheet" href="css/style.css">

    <style>

      .box {
        position: relative;
        background: #cea67a;
      }

      .logout {
      position: absolute;
      right: 44%;
      bottom: 10%;
      }

       .button {
        padding: 50px;
        border-radius:15px;
        background: #cea67a;
        color: #fff;

      }

      .button:hover {
        background: #cea67a;
        color: #000;
        transition: all 0.5s ;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;

      }
    </style>
</head>
<body>
<div class="container">
  
  <div class="box">
    <h3>Add items to your box</h3>
    
    <form method="POST">
      
      <div class="group">      
        <input type="text" id="items" name="items" placeholder="Add items"required>

        <!-- <button type="submit" name="submit" >Add</button> -->
        <a href="list.php">View Box</a>
      </div>
      
    </form>
      <div class="logout">
        <a type="submit" href="logout.php">Logout</a>
      </div>
  </div>
  
</div>


</body>
</html>