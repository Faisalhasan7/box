<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!doctype html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profile</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
      .box {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
      }
      .box>*:first-child {
        align-self: stretch;
      }
      .box .selected {
        align-self: center;
      }

      .small {
        background: #3333;
        padding: 50px;
        border-radius:15px;
        background: #cea67a;
        color: #fff;

      }

      .small:hover {
        background: #cea67a;
        color: #000;
        transition: all 0.5s ;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;

      }

      .box{
        position: relative;
      }

      .box a {
      position: absolute;
      top: 35%;
      right: 35%;
      }

      .logout {
      position: absolute;
      right: 44%;
      bottom: 10%;
      }

    </style>
</head>

  <body>
         
      <div class="box">
        
          <div id="form">
                <div>
                  <h4>Welcome, <?php echo $_SESSION['username'] ?> </h4>
                </div>
                <div>
                  <h3>Let's create a box!</h3>
                </div>
                <div>
                  <a class="small" href="upload.php">Start</a>
                </div>
                <div class="logout">
                  <a type="submit" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </body>
    
</html>